package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.Login;

public interface UserService {

	public List<Login> getUsers();
	public Optional<Login> getUserById(int id);
	public Login addNewUser(Login login);
	public Login updateUser(Login login);
	public void deleteUserById(int id);
	public void deleteAllUsers();
}
