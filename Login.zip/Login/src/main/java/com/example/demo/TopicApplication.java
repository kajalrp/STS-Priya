package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Login;
import com.example.demo.model.Topic;
import com.example.demo.repository.LoginRepository;
import com.example.demo.repository.TopicRepository;
import com.example.demo.service.TopicService;

@SpringBootApplication
@RestController
@RequestMapping(path="/Topic")
@CrossOrigin(origins = "*")
public class TopicApplication {
	
	
	@Autowired
	private TopicRepository topicrepository;
	
	@Autowired
	private TopicService service;
	

	@PostMapping("/topic")
	public String topic(@RequestBody Topic topic) {


		topicrepository.save(topic);
		return "Hi you have successfully logged in by" + topic.getTopic_name();
	}
	
	 @GetMapping(path="/alltopics")
	  public @ResponseBody Iterable<Topic> getTopics() {
	    // This returns a JSON or XML with the users
		    System.out.println("working");
	    return topicrepository.findAll();

	  }
	 
	 @GetMapping("/findTopic/{id}")
	    public Topic findTopic(@PathVariable int id) {
	        return topicrepository.findById(id);

		}
	 
	 
	 

	    @RequestMapping(value= "/user/deleteallTopics", method= RequestMethod.DELETE)
	    public void deleteAll() {
	        System.out.println("Invokeed all");

	        service.deleteAllTopics();
	    }
		

		@DeleteMapping("/cancel/{id}")
	    public List<Topic> deleteTopic(@PathVariable int id) {
			System.out.println("Invokeed cancel");

		topicrepository.deleteById(id);
		return topicrepository.findAll();
	        
		}
	
//		@RequestMapping(value= "/cancel/{id}", method= RequestMethod.DELETE)
//	    public List<Topic> cancelTopic(@PathVariable int id) throws Exception {
//	        System.out.println("Invokeed all");
//
//	        Optional<Topic> topic =  service.getTopicById(id);
//	        if(!topic.isPresent())
//	            throw new Exception("Could not find employee with id- " + id);
//	 
//	        service.deleteTopicById(id);
//		    return topicrepository.findAll();
//	    }
		

//		@DeleteMapping("/cancel/{id}")
//	    public List<Topic> cancelTopic(@PathVariable int id) {
//			System.out.println("delete function");
//	        service.deleteTopicById(id);
//		    return topicrepository.findAll();
//	    }
		
		
		
		@RequestMapping(value= "/user/update/{id}", method= RequestMethod.PUT)
	    public Topic updateTopic(@RequestBody Topic updtopic, @PathVariable int id) throws Exception {
	 
	       Topic topic =  service.getTopicById(id);
	       
	        /* IMPORTANT - To prevent the overriding of the existing value of the variables in the database, 
	         * if that variable is not coming in the @RequestBody annotation object. */    
	        if(updtopic.getTopic_name() == null || updtopic.getTopic_name().isEmpty())
	        	updtopic.setTopic_name(topic.getTopic_name());
	        if(updtopic.getTopic_description() == null || updtopic.getTopic_description().isEmpty())
	        	updtopic.setTopic_description(topic.getTopic_description());
	        if(updtopic.getModified_by() == null || updtopic.getModified_by().isEmpty())
	        	updtopic.setModified_by(topic.getModified_by());	        
	        updtopic.setId(id);
	        updtopic.setCreated_by(topic.getCreated_by());
	      //  updtopic.setModified_date(topic.getModified_date());

	        return service.updateTopic(updtopic);
	    }
//		
		
	public static void main(String[] args) {
		SpringApplication.run(TopicApplication.class, args);
	}


}
