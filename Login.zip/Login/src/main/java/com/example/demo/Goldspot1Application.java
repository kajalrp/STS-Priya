package com.example.demo;

public class Goldspot1Application {

}
