package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;

@Entity

@Table(name="Login_users")
@DynamicInsert
@DynamicUpdate
public class Login {
	
	@Id
	  @GeneratedValue(strategy=GenerationType.AUTO)
	  private Integer id;

	  public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	private String user_name;
	@Column(name="password", nullable=false, length=200)
	  private String password;
		  
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public String getUser_name() {
			return user_name;
		}
		public void setUser_name(String user_name) {
			this.user_name = user_name;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public Login(Integer id, String user_name, String password) {
			super();
			this.id = id;
			this.user_name = user_name;
			this.password = password;
		}
		@Override
		public String toString() {
			return "Login [id=" + id + ", user_name=" + user_name + ", password=" + password + "]";
		}

}