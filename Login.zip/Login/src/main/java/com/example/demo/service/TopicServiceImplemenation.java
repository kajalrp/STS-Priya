package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Topic;
import com.example.demo.repository.LoginRepository;
import com.example.demo.repository.TopicRepository;
@Service

public class TopicServiceImplemenation implements TopicService{

	
	 @Autowired
	    TopicRepository topicRepository;
	 
	 
	@Override
	public List<Topic> getTopics() {
		// TODO Auto-generated method stub
		return topicRepository.findAll();
	}

	@Override
	public Topic getTopicById(int id) {
		// TODO Auto-generated method stub
		return topicRepository.findById(id);
	}

	@Override
	public Topic addNewTopic(Topic topic) {
		// TODO Auto-generated method stub
		return topicRepository.save(topic);
	}

	@Override
	public Topic updateTopic(Topic topic) {
		// TODO Auto-generated method stub
		return topicRepository.save(topic);
	}

	@Override
	public void deleteTopicById(int id) {
		// TODO Auto-generated method stub
		topicRepository.deleteById(id);

	}

	@Override
	public void deleteAllTopics() {
		// TODO Auto-generated method stub
		topicRepository.deleteAll();

	}

}
